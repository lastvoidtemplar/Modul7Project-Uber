﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace Data.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(50,ErrorMessage ="Firstname is too long!")]
        public string FirstName { get; set; }
        [Required]
        [MaxLength(50, ErrorMessage = "Lastname is too long!")]
        public string LastName { get; set; }
        [Required]
        [MinLength(14, ErrorMessage = "Age must be more that 14!")]
        public int Age { get; set; }
        [DefaultValue(0)]
        public int CountOrders { get; set; }
    }
}
